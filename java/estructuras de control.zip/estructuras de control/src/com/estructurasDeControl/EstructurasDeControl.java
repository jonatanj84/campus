package com.estructurasDeControl;

public class EstructurasDeControl {

    public static void main(String[] args) {
        
        String[] texto = {"Este", "es", "un", "bucle", "que", "permite", "concatenar", "texto"};

            for(int i = 0; i < texto.length; i++){
            System.out.print(texto[i]+ " ");
        }

    }
    
}
