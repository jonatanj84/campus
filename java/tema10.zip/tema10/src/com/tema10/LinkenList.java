package com.tema10;

public class LinkenList<T> {

}
