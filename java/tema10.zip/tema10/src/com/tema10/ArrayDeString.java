package com.tema10;

public class ArrayDeString {
    public static void main(String[] args) {
        String array[] = {"nombre", "Apellido", "Direccion", "Edad"};

        for (String arrayN : array) {
            System.out.println(arrayN);
            
        }
    }

}
