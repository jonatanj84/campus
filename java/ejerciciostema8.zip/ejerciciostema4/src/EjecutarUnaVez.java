import java.security.PublicKey;

public class EjecutarUnaVez {
   public static void main(String[] args) {
    int contador = 0;

    do{
        System.out.println(contador);
        contador = contador + 1;
    }while(contador == 3);
   }
}
