import javax.swing.plaf.basic.BasicInternalFrameTitlePane.SystemMenuBar;


public class incrementa {
    public static void main(String[] args) {
      
    int contador = 0;

    while(contador <= 3){
        System.out.println(contador);
        contador = contador + 1;
   
    }
    }
}
