public class App {
    public static void main(String[] args) throws Exception {
        int numero = -1;
        if(numero >= 0){
            System.out.println("Es positivo");  
        }else {
            System.out.println("Es negativo");
        }
             
    }
}
