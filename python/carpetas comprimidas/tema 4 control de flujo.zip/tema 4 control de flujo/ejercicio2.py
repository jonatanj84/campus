for numero in range(2, 8):
    if numero == 2:
        continue
    elif numero == 4:
        continue
    elif numero == 6:
        continue
    elif numero == 8:
        continue
    print(numero)