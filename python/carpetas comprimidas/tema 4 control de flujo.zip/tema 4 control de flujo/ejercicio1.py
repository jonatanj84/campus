usuario = input("ingresa tu edad: ")
usuario = int(usuario)
print(usuario)

if usuario >= 18:
    print("Es mayor de ead")

else :
    print("Es menor de edad")
    
