contador = 1

while contador <= 10:
    if contador % 2 == 0:

      print(contador)

    contador+=1

   
   