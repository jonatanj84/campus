import operaciones

def main():

    print (operaciones.suma(2 , 2))
    print (operaciones.resta(2 , 2))
    print (operaciones.multiplica(2 , 2))
    print (operaciones.dividir(2 , 2))
   

if  __name__=='__main__':
    main()